//: Playground - noun: a place where people can play

import UIKit

let numbers = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

var oneHundredNumber = [Int]()
for i in 1...105{
    oneHundredNumber.append(i)
    
}

for num in oneHundredNumber {

    if num % 15 == 0  && num % 21 == 0 && num % 35 == 0 {
        print ("\(num) fizzbuzzing")

    } else if num % 15 == 0 {
        print ("\(num) fizzbuzz")

    } else if num % 3 == 0 {
        print ("\(num) Buzz")
        
    } else if num % 5 == 0 {
        print("\(num) Buzz")
        
    } else if num % 7 == 0 {
    print ("\(num) Bang")
    
    } else {
    print (num)
    
    }
}
